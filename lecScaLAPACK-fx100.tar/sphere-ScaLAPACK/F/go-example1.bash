#!/bin/bash
#PJM -L "rscgrp=fx-debug"
#PJM -L "node=1"
#PJM --mpi "proc=6"
#PJM -L "elapse=1:00"
mpirun ./example1



