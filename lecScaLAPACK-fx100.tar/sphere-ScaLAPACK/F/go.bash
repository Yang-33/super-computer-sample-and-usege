#!/bin/bash
#PJM -L "rscgrp=fx-debug"
#PJM -L "node=4"
#PJM --mpi "proc=64"
#PJM -L "elapse=1:00"
mpirun ./test



