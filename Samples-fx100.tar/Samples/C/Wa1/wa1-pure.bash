#!/bin/bash
#PJM -L "rscgrp=fx-debug"
#PJM -L "node=12"
#PJM --mpi "proc=128"
#PJM -L "elapse=1:00"
mpirun ./wa1



